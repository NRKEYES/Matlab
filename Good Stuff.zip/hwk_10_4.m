
clear;

h = linspace(.0001,10,100);
e =4.*h.^4;

loglog(h,e);